# read wine data from file. Edit the wine.dat to add column names in first line
wine.table=read.delim("wine.data.txt",sep=",")
# Take columns 2 to 14 for analysis. Ignoring first column, class labels here.
wine_data=wine.table[2:14]
#attach(wine_data)
# Scale wine data
wine_data.s=scale(wine_data,center=TRUE,scale=TRUE)
# Find correlation values 
wine_data.cor=cor(wine_data)
wine_data.cor
# Find eigen vectors and eigen values
wine_data.eig=eigen(wine_data.cor)
# Extract eigen values
wine_data.eigval=cbind(wine_data.eig$values)
wine_data.eigval
# find sum of eigenv values
sum(wine_data.eigval)
# Proportion of wine data for each PC
pr_wine_data.eigenval=wine_data.eigval/sum(wine_data.eigval)
pr_wine_data.eigenval
pr_wine_data.eigenvectors=cbind(wine_data.eig$vectors)
pr_wine_data.eigenvectors
# Cumulative sum of of eigen vals
cumsum(pr_wine_data.eigenval)
# Plot of how much percentage each principle component covers. 
plot(pr_wine_data.eigenval*100,
     ylab="Percent of variance",
     xlab="Principle components",
     cex.lab=0.75,col="blue",type="o",
     main="Percent of variance for each PC")
# Plot of cumulative sum of principle components. 
# First 4 components explain upto 73% of the data
# First 5 components explain up 80% of the data
plot(cumsum(pr_wine_data.eigenval)*100,
     ylab="Cumulative Percent of total variance",
     xlab="Principle components",
     cex.lab=0.75,col="red",type="o",
     main="Cumulative Percent of variance for each PC")

# Perform hierarichal clustering analysis.
# First we will project the given data in PC coordinate system
# by doing matrix multiplication of scaled wine data with eigen vector
wine_data.new=wine_data.s%*%pr_wine_data.eigenvectors
# Add column names
colnames(wine_data.new)=c("PC1","PC2","PC3","PC4","PC5","PC6","PC7","PC8","PC9","PC10","PC11","PC12","PC13")
# Clustering reduced number of dimensions, using first 2 PCs
wine_data.RD=wine_data.new[,c(1,2)]
# Clustering reduced number of dimensions, using first 4 PCs
#wine_data.RD=wine_data.new[,c(1,2,3,4)]
wineclust=hclust(dist(wine_data.RD),method="ward.D2")
# store the labels, for later use
X = t(wine.table[,1])
# Create denodgram
plot(wineclust,labels=X,cex=0.40,hang=-2)