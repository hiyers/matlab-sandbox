% PCA Analysis of given Wine data
%Load data from text file to Matalb
wine=readtable('wine.data.txt');
% Name all the columns
wine.Properties.VariableNames{1} = 'Class';
wine.Properties.VariableNames{2} = 'Alcohol';
wine.Properties.VariableNames{3} = 'MalicAcid';
wine.Properties.VariableNames{4} = 'Ash';
wine.Properties.VariableNames{5} = 'AlcalOfAsh';
wine.Properties.VariableNames{6} = 'Magnesium';
wine.Properties.VariableNames{7} = 'TotalPhenol';
wine.Properties.VariableNames{8} = 'Flavanoids';
wine.Properties.VariableNames{9} = 'NonFlavanoidPhenols';
wine.Properties.VariableNames{10} = 'Proanthocyanins';
wine.Properties.VariableNames{11} = 'ColorIntensity';
wine.Properties.VariableNames{12} = 'Hue';
wine.Properties.VariableNames{13} = 'OD280_OD315_dw';
wine.Properties.VariableNames{14} = 'Proline';
%Copy Class variable as Labels
Labels=table2array(wine(:,1));
% Remove Class column
wine=removevars(wine,'Class');
% Convert table data to matrix
wine_data=table2array(wine);
% Find mean of matrix
wine_data_mean = mean(wine_data);
% create pre-process data by substracting mean
prep_wine_data=wine_data-wine_data_mean;
% find standard deviation of wine data
wine_data_std=std(wine_data);
% normalized wine data (data-mean)/std 
norm_wine_data=prep_wine_data./wine_data_std;
% perform PCA using NETLAB function
[pcvals,pcvecs]=pca(norm_wine_data);
% Create projdata using formula
projdata=norm_wine_data*pcvecs(:,1:2);
% Open Figure 1
figure(1)
hold on;
% Create plot for label 1
h1=plot(projdata(Labels==1,1),projdata(Labels==1,2),'rx','MarkerSize',6);
% Create plot for label 2
h2=plot(projdata(Labels==2,1),projdata(Labels==2,2),'bo','MarkerSize',6);
% Create plot for label 3
h3=plot(projdata(Labels==3,1),projdata(Labels==3,2),'kd','MarkerSize',6);
% Labeling 
set(gca,'Box','on');
legend('Class 1','Class 2','Class 3');
xlabel('PC1');
ylabel('PC2');
save wine_pca.mat