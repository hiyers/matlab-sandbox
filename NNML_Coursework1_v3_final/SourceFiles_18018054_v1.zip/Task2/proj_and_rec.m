% Matlab function to project and recover image data 
function recoverImageMatByN = proj_and_rec(x,pcvecs,n)
    % Select first n pc
    firstNpc=pcvecs(:,1:n);
    % Projection of normalized immat on PC 
    projimgN=x*firstNpc;%pcvecs(:,1:n);
    % Recover image matrix using first n PC
    recoverImageMatByN=projimgN*firstNpc';
end