% Load image into matrix - immat
immat=imread('boat.512.tiff');
% Convert back to image - not required
% imagesc(uint8(immat))
% colormap(gray)
% Convert uint8 to double
immat=double(immat);
% Find mean of img data (immat)
mean_immat=mean(immat);
% Find standard deviation of img data
std_immat=std(immat);
% Normalize data
%x=(immat-mean_immat);%./std_immat;
x=(immat-mean_immat)./std_immat;
% Perform PCA
[pcvals,pcvecs]=pca(x);
disp(sum(pcvals));
% project and recover with different no. of PC components
for n = 1:512
  if n==4 | n==10 | n==15 | n==512 
    % call matlab function to project the image data in PC coordinates and recover back
    % to original coordinate system
    recoverImageMatByN = proj_and_rec(x,pcvecs,n);
    % add mean and Display Recovered image 
    % muliply by stdev and add the subtracted meanval to bring pixels in 0-255 range
    recoverImageMatByN1=((recoverImageMatByN).*std_immat)+mean_immat;
    %disp(recoverImageMatByN1);
    %recoverImageMatBy4=(recoverImageMatBy4+mean_immat).*std_immat;
    fprintf('Figure %d -> image recovered by using first %d principle components.\n',n,n)
    figure(n)
    %imshow(int8(recoverImageMatBy4));
    imagesc(uint8(recoverImageMatByN1));
    colormap(gray);
  end 
end    