% K-means clustering on given wine data.
%Load data from text file to Matalb
wine=readtable('wine.data.txt');
% Name all the columns
wine.Properties.VariableNames{1} = 'Class';
wine.Properties.VariableNames{2} = 'Alcohol';
wine.Properties.VariableNames{3} = 'MalicAcid';
wine.Properties.VariableNames{4} = 'Ash';
wine.Properties.VariableNames{5} = 'AlcalOfAsh';
wine.Properties.VariableNames{6} = 'Magnesium';
wine.Properties.VariableNames{7} = 'TotalPhenol';
wine.Properties.VariableNames{8} = 'Flavanoids';
wine.Properties.VariableNames{9} = 'NonFlavanoidPhenols';
wine.Properties.VariableNames{10} = 'Proanthocyanins';
wine.Properties.VariableNames{11} = 'ColorIntensity';
wine.Properties.VariableNames{12} = 'Hue';
wine.Properties.VariableNames{13} = 'OD280_OD315_dw';
wine.Properties.VariableNames{14} = 'Proline';
%Copy Class variable as Labels
Labels=table2array(wine(:,1));
% Remove Class column
wine=removevars(wine,'Class');
% Convert table data to matrix
wine_data=table2array(wine);
% Find mean of matrix
wine_data_mean = mean(wine_data);
% create pre-process data by substracting mean
prep_wine_data=wine_data-wine_data_mean;
% find standard deviation of wine data
wine_data_std=std(wine_data);
% normalized wine data (data-mean)/std 
norm_wine_data=prep_wine_data./wine_data_std;
% start k-Means clustering process, load normalized data
% Set parameters and call K means for K=3
data=norm_wine_data;
rand('state',0);
ndata = size(data, 1);
ncentres = 3; % 3 codevectors
perm = randperm(ndata); 
perm = perm(1:ncentres);
centres = data(perm, :);
options = foptions;
options(1)  = 1;		% Prints out error values.
options(14) = 10;		% Number of iterations.
% Train the centres from the data
disp('Perform K means using 3 code vectors');
[centres, options, post] = kmeans(centres, data, options);
[one_value, membership] = max(post,[],2);
% repeat the same process for K=5
data=norm_wine_data;
rand('state',0);
ndata = size(data, 1);
ncentres = 5; % 5 codevectors
perm = randperm(ndata); 
perm = perm(1:ncentres);
centres = data(perm, :);
options = foptions;
options(1)  = 1;		% Prints out error values.
options(14) = 15;		% Number of iterations.
% Train the centres from the data
disp('------------------------------------');
disp('Perform K means using 5 code vectors');
[centres, options, post] = kmeans(centres, data, options);
[one_value, membership] = max(post,[],2);

