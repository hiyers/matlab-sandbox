% K-means cluster analysis of given wine data.
%Load data from text file to Matalb
wine=readtable('wine.data.txt');
% Name all the columns
wine.Properties.VariableNames{1} = 'Class';
wine.Properties.VariableNames{2} = 'Alcohol';
wine.Properties.VariableNames{3} = 'MalicAcid';
wine.Properties.VariableNames{4} = 'Ash';
wine.Properties.VariableNames{5} = 'AlcalOfAsh';
wine.Properties.VariableNames{6} = 'Magnesium';
wine.Properties.VariableNames{7} = 'TotalPhenol';
wine.Properties.VariableNames{8} = 'Flavanoids';
wine.Properties.VariableNames{9} = 'NonFlavanoidPhenols';
wine.Properties.VariableNames{10} = 'Proanthocyanins';
wine.Properties.VariableNames{11} = 'ColorIntensity';
wine.Properties.VariableNames{12} = 'Hue';
wine.Properties.VariableNames{13} = 'OD280_OD315_dw';
wine.Properties.VariableNames{14} = 'Proline';
%Copy Class variable as Labels
Labels=table2array(wine(:,1));
% Remove Class column
wine=removevars(wine,'Class');
% Convert table data to matrix
wine_data=table2array(wine);
% Find mean of matrix
wine_data_mean = mean(wine_data);
% create pre-process data by substracting mean
prep_wine_data=wine_data-wine_data_mean;
% find standard deviation of wine data
wine_data_std=std(wine_data);
% normalized wine data (data-mean)/std 
norm_wine_data=prep_wine_data./wine_data_std;
%-------------------------------------------------------------------------------%
% start k-Means clustering process for K=3, load normalized data
data=norm_wine_data;
rand('state',0);
ndata = size(data, 1);
ncentres = 3; % 3 codevectors
perm = randperm(ndata); 
perm = perm(1:ncentres);
centres = data(perm, :);
options = foptions;
options(1)  = 1;		% Prints out error values.
options(14) = 10;		% Number of iterations.
% Train the centres from the data
disp('------------------------------------');
disp('Perform K means using 5 code vectors');
[centres, options, post] = kmeans(centres, data, options);
[one_value, membership] = max(post,[],2);
%Perform PCA to find pcvecs
[pcvals,pcvecs]=pca(norm_wine_data);
% Create projdata using formula
projdata=norm_wine_data*pcvecs(:,1:2);
% Open Figure 11
figure(11)
hold on;
% Create plot for cluster 1
h1=plot(projdata(membership==1,1),projdata(membership==1,2),'r.','MarkerSize',12);
% Create plot for cluster 2
h2=plot(projdata(membership==2,1),projdata(membership==2,2),'b.','MarkerSize',12);
% Create plot for cluster 3
h3=plot(projdata(membership==3,1),projdata(membership==3,2),'g.','MarkerSize',12);

% Labeling 
set(gca,'Box','on');
xlabel('PC1');
ylabel('PC2');
% Project Kmeans centers on PCA Plot (3 Clusters)
projcentres=centres*pcvecs(:,1:2);
hc3=plot(projcentres(:,1),projcentres(:,2),'k.','LineWidth',2,'MarkerSize',18);
legend('Cluster1','Cluster2','Cluster3','CV');
% --- end K means PC projection for K=3 ---%
%-------------------------------------------------------------------------------%
% start k-Means clustering process for K=5, load normalized data
data=norm_wine_data;
rand('state',0);
ndata = size(data, 1);
ncentres = 5; % 5 codevectors
perm = randperm(ndata); 
perm = perm(1:ncentres);
centres = data(perm, :);
options = foptions;
options(1)  = 1;		% Prints out error values.
options(14) = 15;		% Number of iterations.
% Train the centres from the data
disp('------------------------------------');
disp('Perform K means using 5 code vectors');
[centres, options, post] = kmeans(centres, data, options);
[one_value, membership] = max(post,[],2);
%Perform PCA to find pcvecs
[pcvals,pcvecs]=pca(norm_wine_data);
% Create projdata using formula
projdata=norm_wine_data*pcvecs(:,1:2);
% Open Figure 12
figure(12)
hold on;
% Create plot for cluster 1
h4=plot(projdata(membership==1,1),projdata(membership==1,2),'r.','MarkerSize',12);
% Create plot for cluster 2
h5=plot(projdata(membership==2,1),projdata(membership==2,2),'b.','MarkerSize',12);
% Create plot for cluster 3
h6=plot(projdata(membership==3,1),projdata(membership==3,2),'g.','MarkerSize',12);
% Create plot for cluster 4
h7=plot(projdata(membership==4,1),projdata(membership==4,2),'c.','MarkerSize',12);
% Create plot for cluster 5
h8=plot(projdata(membership==5,1),projdata(membership==5,2),'m.','MarkerSize',12);
% Labeling 
set(gca,'Box','on');
xlabel('PC1');
ylabel('PC2');
% Project Kmeans centers on PCA Plot (5 Clusters)
projcentres=centres*pcvecs(:,1:2);
hc5=plot(projcentres(:,1),projcentres(:,2),'k.','LineWidth',2,'MarkerSize',18);
legend('Cluster1','Cluster2','Cluster3','Cluster4','Cluster5','CV');
% --- end K means PC projection for K=5 ---%
