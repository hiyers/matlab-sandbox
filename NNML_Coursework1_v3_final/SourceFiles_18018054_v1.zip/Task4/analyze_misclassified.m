% Load actual data/given labels
load wine.mat
% Load predicted labels from task 3
load predicted.output
% Get tstdata projected on Principal components
mean_trndata=mean(trndata);
mean_tstdata=mean(tstdata);
std_trndata=std(trndata);
std_tstdata=std(tstdata);
norm_trndata=(trndata-mean_trndata)./std_trndata;
norm_tstdata=(tstdata-mean_tstdata)./std_tstdata;
% Perform PCA using training data set
[pcvals,pcvecs]=pca(norm_trndata);
% Project test data set
projtstdata = norm_tstdata*pcvecs(:,1:2);
figure(1)
hold on
h1=plot(projtstdata(tstlabels==1,1),projtstdata(tstlabels==1,2),'r.','MarkerSize',10);
h2=plot(projtstdata(tstlabels==2,1),projtstdata(tstlabels==2,2),'b.','MarkerSize',10);
h3=plot(projtstdata(tstlabels==3,1),projtstdata(tstlabels==3,2),'g.','MarkerSize',10);
h4=plot(projtstdata(tstlabels~=predicted,1),projtstdata(tstlabels~=predicted,2),'kx','MarkerSize',10);
legend('Class 1','Class 2','Class 3','Misclassified');
xlabel('PC1');
ylabel('PC2');
set(gca,'Box','on') 